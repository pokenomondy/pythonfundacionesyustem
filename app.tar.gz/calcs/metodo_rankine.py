import math
from functools import reduce

#Calculo del empuje metodo Rankine
class Rankine:
    def __init__(self, Y_rell, phi_rell, C_rell, Y_fundacion, phi_fundacion, y_conc, phi_conc, C_fundacion, alpha, betha, H, D, b, h1, b1, b2, t1, t2, h_rankine, alpha_rankine):
        self.Y_rell = Y_rell
        self.phi_rell = phi_rell
        self.C_rell = C_rell
        self.Y_fundacion = Y_fundacion
        self.phi_fundacion = phi_fundacion
        self.C_fundacion = C_fundacion
        self.y_conc = y_conc
        self.phi_conc = phi_conc
        self.alpha = alpha
        self.betha = betha
        self.D = D
        self.b = b
        self.h1 = h1
        self.b1 = b1
        self.b2 = b2
        self.t1 = t1
        self.t2 = t2
        self.h_rankine = h_rankine
        self.H = H
        self.B = self.b1 + self.b2 + self.t1 + self.t2 + self.b
        self.alpha_rankine = alpha_rankine

        #util funtions
        def compute_expression_ka(alpha, phi_rell):
            try:
                cos_alpha = math.cos(math.radians(alpha))
                cos_phi_rell = math.cos(math.radians(phi_rell))
                numerator = cos_alpha * (cos_alpha - math.sqrt(cos_alpha**2 - cos_phi_rell**2))
                denominator = cos_alpha + math.sqrt(cos_alpha**2 - cos_phi_rell**2)
                result = numerator / denominator
                return result
            except Exception as e:
                return -1

        def compute_expression_kp(alpha_rankine, phi_fundacion):
            cos_alpha_rankine = math.cos(math.radians(alpha_rankine))
            cos_phi_fundacion = math.cos(math.radians(phi_fundacion))
            numerator = cos_alpha_rankine * (cos_alpha_rankine + math.sqrt(cos_alpha_rankine**2 - cos_phi_fundacion**2))
            denominator = cos_alpha_rankine - math.sqrt(cos_alpha_rankine**2 - cos_phi_fundacion**2)
            result = numerator / denominator
            return result

        dominio_nulo = False

        #Calculos Ka
        self.Ka = compute_expression_ka(alpha=self.alpha, phi_rell=self.phi_rell)
        if self.Ka == -1:
            dominio_nulo = True
        self.H_rankine = self.H + self.h1 + self.h_rankine
        self.Pa = 1/2 * self.Ka * self.Y_rell * self.H_rankine ** 2
        self.Y = self.H_rankine / 3
        self.PaH = self.Pa * math.cos(math.radians(self.alpha))
        self.PaV = self.Pa * math.sin(math.radians(self.alpha))
        self.Ma = self.Y * self.PaH

        #Calculos kp
        self.Kp = compute_expression_kp(alpha_rankine=self.alpha_rankine, phi_fundacion=self.phi_fundacion)
        self.esfP = 2 * self.C_fundacion * math.sqrt(self.Kp)
        self.ESFP = self.Y_fundacion * self.Kp * self.D + self.esfP
        self.Pp = (self.esfP + self.ESFP) / 2 * self.D

        #fuerzas
        fuerzas = [1/2*self.t1*self.H*self.y_conc, self.y_conc*self.H*self.b, 1/2*self.y_conc*self.H*self.t2, self.y_conc* self.B * self.h1, 1/2 * self.Y_fundacion * self.H * self.t2, self.Y_rell * self.H * self.b2, 1/2 * self.h_rankine * (self.b2 + self.t2) * self.Y_rell, self.PaV]
        self.fuerza_total = reduce(lambda x,y: x + y, fuerzas)
        brazos = [self.b1+2/3*self.t1, self.b1 + self.t1 + self.b/2, self.b1 + self.t1 + self.b + 2/3*self.t2, self.B/2, self.B-self.b2+2/3*self.t2, self.B - self.b2/2, self.B-self.t2-self.b2+2/3*(self.b2+self.t2), self.B]
        momentos = list(map(lambda f, b: f * b, fuerzas, brazos))
        self.momento_total = reduce(lambda x, y : x + y, momentos)
        self.fs_volteo = self.momento_total / self.Ma
        parcial = 2/3 * self.phi_fundacion
        FHR1 = self.fuerza_total * math.tan(math.radians(parcial))
        FHR2 = 2/3 * self.C_fundacion * self.B
        F_RESISTENTES = self.Pp + FHR1 + FHR2
        self.fs_deslizamiento = F_RESISTENTES / self.PaH
        x = (self.momento_total-self.Ma)/(self.fuerza_total)
        self.excentricidad = self.B/2 - x

        #cumplimiento
        if dominio_nulo:
            self.cumplimiento_volteo = False
            self.cumplimiento_deslizamiento = False
            self.cumplimiento_excentricidad = False
            self.cumplimiento_sistema = False
        else:
            self.cumplimiento_volteo = self.fs_volteo >= 3
            self.cumplimiento_deslizamiento = self.fs_deslizamiento >= 1.6
            self.cumplimiento_excentricidad = x >= self.B/3 and x <= 2/3*self.B
            self.cumplimiento_sistema = self.cumplimiento_volteo and self.cumplimiento_deslizamiento and self.cumplimiento_excentricidad


    def ver_cumplimiento(self):
        resultado = ""
        if self.cumplimiento_volteo:
            resultado += '\nFS Por Volteo cumple'
        else:
            resultado += '\nFS por Volteo no cumple'
        if self.cumplimiento_deslizamiento:
            resultado += '\nFS por deslizamiento cumple'
        else:
            resultado += '\nFS por deslizamiento no cumple'
        if self.cumplimiento_excentricidad:
            resultado += '\nExcentricidad cumple'
        else:
            resultado += '\nExcentricidad no cumple'
        if self.cumplimiento_sistema:
            resultado += '\nSistema cumple'
        else:
            resultado += '\nSistema no cumple'
        return resultado



    def resultados_ka(self):
        return f"Ka: {self.Ka}\n H(m): {self.H_rankine}\nPa(kN/M): {self.Pa}\nY(m): {self.Y}\nPaH: {self.PaH}\nPaV: {self.PaV}\nMomento Actuante: {self.Ma}"

    def resultados_kp(self):
        return f"Kp: {self.Kp}\nesfP: {self.esfP}\nESFP: {self.ESFP}\nPp: {self.Pp}"

    def ver_resultados(self):
        return f"Fuerza normal = N(kN/M) = {self.fuerza_total}\nMomento resistente = MR (kN*M) = {self.momento_total}\nF.S por volteo = {self.fs_volteo}\nF.S al deslizamiento = {self.fs_deslizamiento}\nExcentricidad = {self.excentricidad}"


def run():
    rankine = Rankine(Y_rell=18, phi_fundacion=20, C_rell=0, Y_fundacion=19, phi_rell=30, C_fundacion=40, alpha=10, betha=90, H=6, D=1.5, b=0.5, h1=0.7, b1=0.7, b2=2.6, t1=0.2, t2=0, h_rankine=0.46, alpha_rankine=0, y_conc=23.58, phi_conc=0)
    print(rankine.resultados_ka())
    print(rankine.resultados_kp())
    print(rankine.ver_resultados())
    print(rankine.ver_cumplimiento())

if __name__ == "__main__":
    run()