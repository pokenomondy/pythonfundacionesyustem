import matplotlib.pyplot as plt
import matplotlib

def graficar(b, B, h1, b1, b2, t1, t2, H, D):
    fig, ax = plt.subplots()

    x = [0, B, B, B - b2, B - b2 - t2, B - b2 - t2 - b, B - b2 - t2 - b - t1, B - b2 - t2 - b - t1 - b1, 0]
    y = [0, 0, h1, h1, h1 + H, h1 + H, h1, h1, 0]

    ax.plot(x, y)

    ax.fill_between(x, y, color='lightblue')

    # x_rectangle = [0,B+B*0.1,B+B*0.1,0,0]
    # y_rectangle = [0,0,D,D,0]

    # ax.fill_between(x, y, color='lightred')

    ax.set_xlabel('X axis label')
    ax.set_ylabel('Y axis label')
    ax.set_title('Muro de contencion')

    return fig