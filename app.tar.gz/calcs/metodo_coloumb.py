import math
from functools import reduce

#clase de metodo rankine
class Coloumb:
    def __init__(self, phi_rell, Y_rell, C_rell, d, alpha, y_conc, k, phi_conc, Y_fundacion, phi_fundacion, C_fundacion, H, h1, t2, tetha, betha, alpha_kb, t1, b, B, b1):
        self.phi_rell = phi_rell
        self.Y_rell = Y_rell
        self.C_rell = C_rell
        self.d = d
        self.alpha = alpha
        self.y_conc = y_conc
        self.betha = betha
        self.H = H
        self.b = b
        self.b1 = b1
        self.B = B
        self.h1 = h1
        self.k = k
        self.t1 = t1
        self.phi_conc = phi_conc
        self.Y_fundacion = Y_fundacion
        self.phi_fundacion = phi_fundacion
        self.C_fundacion = C_fundacion
        self.alpha_kb = alpha_kb
        self.t2 = t2
        self.tetha = tetha
        
        #Coloumb Ka
        self.parcial = self.phi_rell * self.k
        numerador = math.sin(self.betha + self.phi_rell)**2
        numerador_raiz = math.sin(self.phi_rell + self.parcial)*math.sin(self.phi_rell-self.alpha) 
        denominador_raiz = math.sin(self.betha - self.parcial)*math.sin(self.alpha + self.betha)
        try:
            raiz = math.sqrt(numerador_raiz/denominador_raiz) ** 2
            dominio_nulo = False
        except Exception as e:
            raiz = 1
            dominio_nulo = True
        denominador_sin_1 = math.sin(self.betha)**2
        denominador_sin_2 = math.sin(self.betha - self.parcial)
        denominador = denominador_sin_1 * denominador_sin_2 * (1 + raiz)
        self.ka = numerador / denominador
        self.H_ejercicio = H + h1
        self.Pa = 1/2*self.Y_rell*self.ka*self.H_ejercicio**2
        self.y = self.H_ejercicio / 3
        self.PaH = self.Pa*math.cos(math.radians(self.parcial+self.tetha))
        self.PaV = self.Pa*math.sin(math.radians(self.parcial+self.tetha))
        self.Ma = self.y * self.PaH
        
        #Coloumb Kb
        self.parcialB = self.k * self.phi_fundacion
        numerador = math.sin(self.betha - self.phi_fundacion)**2
        denominador_sin_2 = math.sin(self.betha + self.parcialB)
        numerador_raiz = math.sin(self.phi_fundacion + self.parcialB) * math.sin(self.phi_fundacion + self.alpha_kb)
        denominador_raiz = math.sin(self.betha + self.parcialB) * math.sin(self.betha + self.alpha_kb)
        try:
            raiz = math.sqrt(numerador_raiz/denominador_raiz)
            dominio_nulo = False
        except:
            raiz = 1
            dominio_nulo = True
        raiz_operada = (1 - raiz) ** 2
        denominador = denominador_sin_1 * denominador_sin_2 * raiz_operada
        try:
            self.kp = numerador / denominador
            dominio_nulo = False
        except:
            self.kp = 1
            dominio_nulo = True
        try:
            self.Pp_Cohesion = 2 * self.C_fundacion * math.sqrt(self.kp) * self.d
            dominio_nulo = False
        except Exception as e:
            self.Pp_Cohesion = 1
            dominio_nulo = True
        self.Pp_parcial = 1/2 * self.Y_fundacion * self.kp * self.d ** 2
        self.PpH = self.Pp_parcial * math.cos(math.radians(self.parcialB))
        self.Pp = self.PpH + self.Pp_Cohesion

        #Valores finales
        fuerzas = [1/2*self.t1*self.H*self.y_conc, self.y_conc*self.H*self.b, 1/2*self.y_conc*self.H*self.t2, self.y_conc* self.B * self.h1, self.PaV]
        self.fuerza_total = reduce(lambda x,y: x + y, fuerzas)
        brazos = [self.b1+2/3*self.t1, self.b1 + self.t1 + self.b/2, self.b1 + self.t1 + self.b + 2/3*self.t2, self.B/2, self.b1 + self.b + self.t1 + 2/3 * self.t2]
        momentos = list(map(lambda f, b: f * b, fuerzas, brazos))
        self.momento_total = reduce(lambda x, y : x + y, momentos)
        self.fs_volteo = self.Ma / self.momento_total
        self.FH1 = self.fuerza_total*math.tan(math.radians(self.parcialB))
        self.FH2 = self.C_fundacion*self.k*self.B
        self.fuerzas_resistentes = self.FH1 + self.FH2 + self.Pp
        self.fs_deslizamiento = self.fuerzas_resistentes / self.PaH

        x = (self.momento_total-self.Ma)/self.fuerza_total
        self.excentricidad = self.B/2 - x

        if dominio_nulo:
            self.cumplimiento_volteo = False
            self.cumplimiento_deslizamiento = False
            self.cumplimiento_excentricidad = False
            self.cumplimiento_sistema = False
        else:
            self.cumplimiento_volteo = self.fs_volteo >= 3
            self.cumplimiento_deslizamiento = self.fs_deslizamiento >= 1.6
            self.cumplimiento_excentricidad = x >= self.B/3 and x <= 2/3*self.B
            self.cumplimiento_sistema = self.cumplimiento_volteo and self.cumplimiento_deslizamiento and self.cumplimiento_excentricidad

    def coloumb_ka(self):
        return f"Parcial: {self.parcial}\nH(m): {self.H_ejercicio}\nKa: {self.ka}\nPa(Kn/m): {self.Pa}\nY(m){self.y}\ntetha: {self.tetha}\nPaH: {self.PaH}\nPaV: {self.PaV}\nMA: {self.Ma}"

    def coloumb_kb(self):
        return f"Parcial: {self.parcialB}\nKp: {self.kp}\nPp cohesion: {self.Pp_Cohesion}\nPp Horizontal: {self.PpH}\nPp(kN/m): {self.Pp}"

    def ver_resultados(self):
        return f"Fuerza normal = N(kN/M) = {self.fuerza_total}\nMomento resistente = MR (kN*M) = {self.momento_total}\nF.S por volteo = {self.fs_volteo}\nF.S al deslizamiento = {self.fs_deslizamiento}\nExcentricidad = {self.excentricidad}"

    def ver_cumplimiento(self):
        resultado = ""
        if self.cumplimiento_volteo:
            resultado += '\nFS Por Volteo cumple'
        else:
            resultado += '\nFS por Volteo no cumple'
        if self.cumplimiento_deslizamiento:
            resultado += '\nFS por deslizamiento cumple'
        else:
            resultado += '\nFS por deslizamiento no cumple'
        if self.cumplimiento_excentricidad:
            resultado += '\nExcentricidad cumple'
        else:
            resultado += '\nExcentricidad no cumple'
        if self.cumplimiento_sistema:
            resultado += '\nSistema cumple'
        else:
            resultado += '\nSistema no cumple'
        return resultado

def run():
    coloumb = Coloumb(phi_rell=30, Y_rell=18, C_rell=0, d=1.5, alpha=10, y_conc=23.58, k=(2/3), phi_conc=0, Y_fundacion=19, phi_fundacion=20, C_fundacion=40, H=6, t2=0, tetha=0, betha=90, alpha_kb=0, t1=0.2, h1=0.7, b=0.5, B=4, b1=0.7)
    print(coloumb.ver_resultados())
    coloumb.ver_cumplimiento()

if __name__ == "__main__":
    run()
