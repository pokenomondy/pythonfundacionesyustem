import math
import random as rd
from calcs.metodo_coloumb import Coloumb
from calcs.metodo_rankine import Rankine

#Simulacion montecarlo
class Montecarlo_Coloumb:
    def __init__(self, phi_rell, Y_rell, C_rell, d, alpha, y_conc, k, phi_conc, Y_fundacion, phi_fundacion, C_fundacion, H, h1, t2, tetha, betha, alpha_kb, t1, b, B, b1, iterations=10000):
        self.phi_rell = phi_rell
        self.Y_rell = Y_rell
        self.C_rell = C_rell
        self.d = d
        self.alpha = alpha
        self.y_conc = y_conc
        self.betha = betha
        self.H = H
        self.b = b
        self.b1 = b1
        self.B = B
        self.h1 = h1
        self.k = k
        self.t1 = t1
        self.phi_conc = phi_conc
        self.Y_fundacion = Y_fundacion
        self.phi_fundacion = phi_fundacion
        self.C_fundacion = C_fundacion
        self.alpha_kb = alpha_kb
        self.t2 = t2
        self.tetha = tetha
        self.iterations = iterations

    def run_simulation(self):
        success_count = 0
        success_volteo_count = 0
        sucess_deslizamiento_count = 0
        sucess_excentricidad_count = 0
        results = []

        for _ in range(self.iterations):
            phi_rell_random = rd.uniform(0, 90)
            Y_rell_random = rd.uniform(10, 25)
            C_rell_random = rd.uniform(0, 50)

            coloumb_instance = Coloumb(
                phi_rell=phi_rell_random,
                Y_rell=Y_rell_random,
                C_rell=C_rell_random,
                d=self.d,
                alpha=self.alpha,
                y_conc=self.y_conc,
                k=self.k,
                phi_conc=self.phi_conc,
                Y_fundacion=self.Y_fundacion,
                phi_fundacion=self.phi_fundacion,
                C_fundacion=self.C_fundacion,
                H=self.H,
                h1=self.h1,
                t2=self.t2,
                tetha=self.tetha,
                betha=self.betha,
                alpha_kb=self.alpha_kb,
                t1=self.t1,
                b=self.b,
                B=self.B,
                b1=self.b1
            )

            if coloumb_instance.cumplimiento_volteo:
                success_volteo_count += 1

            if coloumb_instance.cumplimiento_sistema:
                success_count += 1

            if coloumb_instance.cumplimiento_deslizamiento:
                sucess_deslizamiento_count += 1

            if coloumb_instance.cumplimiento_excentricidad:
                sucess_excentricidad_count += 1

            results.append(coloumb_instance.cumplimiento_sistema)

        success_probability = success_count / self.iterations
        sucess_volteo_probability = success_volteo_count / self.iterations
        sucess_delizamiento_probability = sucess_deslizamiento_count / self.iterations
        sucess_excentricidad_probability = sucess_excentricidad_count / self.iterations
        uncertainty = math.sqrt(success_probability * (1 - success_probability) / self.iterations)

        return f"Probabilidad de cumplimiento del sistema: {success_probability:.2%}\nIncertidumbre del sistema: {uncertainty:.4f}\nProbabilidad de cumplimiento del volteo: {sucess_volteo_probability:.2%}\nProbabilidad de cumplimiento del deslizamiento: {sucess_delizamiento_probability:.2%}\nProbabilidad de cumplimiento de excentricidad: {sucess_excentricidad_probability:.2%}"

class Montecarlo_Rankine:
    def __init__(self, Y_rell, phi_rell, C_rell, Y_fundacion, phi_fundacion, y_conc, phi_conc, C_fundacion, alpha, betha, H, D, b, h1, b1, b2, t1, t2, h_rankine, alpha_rankine, iterations=1000):
        self.Y_rell = Y_rell
        self.phi_rell = phi_rell
        self.C_rell = C_rell
        self.Y_fundacion = Y_fundacion
        self.phi_fundacion = phi_fundacion
        self.C_fundacion = C_fundacion
        self.y_conc = y_conc
        self.phi_conc = phi_conc
        self.alpha = alpha
        self.betha = betha
        self.H = H
        self.D = D
        self.b = b
        self.h1 = h1
        self.b1 = b1
        self.b2 = b2
        self.t1 = t1
        self.t2 = t2
        self.h_rankine = h_rankine
        self.alpha_rankine = alpha_rankine
        self.iterations = iterations

    def run_simulation(self):
        success_count = 0
        success_volteo_count = 0
        success_deslizamiento_count = 0
        success_excentricidad_count = 0

        for _ in range(self.iterations):
            Y_rell_random = rd.uniform(10, 25)
            phi_rell_random = rd.uniform(0, 90)
            C_rell_random = rd.uniform(0, 50)

            rankine_instance = Rankine(
                Y_rell=Y_rell_random,
                phi_rell=phi_rell_random,
                C_rell=C_rell_random,
                Y_fundacion=self.Y_fundacion,
                phi_fundacion=self.phi_fundacion,
                y_conc=self.y_conc,
                phi_conc=self.phi_conc,
                C_fundacion=self.C_fundacion,
                alpha=self.alpha,
                betha=self.betha,
                H=self.H,
                D=self.D,
                b=self.b,
                h1=self.h1,
                b1=self.b1,
                b2=self.b2,
                t1=self.t1,
                t2=self.t2,
                h_rankine=self.h_rankine,
                alpha_rankine=self.alpha_rankine
            )

            if rankine_instance.cumplimiento_volteo:
                success_volteo_count += 1

            if rankine_instance.cumplimiento_sistema:
                success_count += 1

            if rankine_instance.cumplimiento_deslizamiento:
                success_deslizamiento_count += 1

            if rankine_instance.cumplimiento_excentricidad:
                success_excentricidad_count += 1

        success_probability = success_count / self.iterations
        success_volteo_probability = success_volteo_count / self.iterations
        success_deslizamiento_probability = success_deslizamiento_count / self.iterations
        success_excentricidad_probability = success_excentricidad_count / self.iterations
        uncertainty = math.sqrt(success_probability * (1 - success_probability) / self.iterations)

        return f"Probabilidad de cumplimiento del sistema: {success_probability:.2%}\nIncertidumbre del sistema: {uncertainty:.4f}\nProbabilidad de cumplimiento del volteo: {success_volteo_probability:.2%}\nProbabilidad de cumplimiento del deslizamiento: {success_deslizamiento_probability:.2%}\nProbabilidad de cumplimiento de excentricidad: {success_excentricidad_probability:.2%}"

def run():
    montecarlo = Montecarlo_Coloumb(
        phi_rell=30,
        Y_rell=18,
        C_rell=0,
        d=1.5,
        alpha=10,
        y_conc=23.58,
        k=2 / 3,
        phi_conc=0,
        Y_fundacion=19,
        phi_fundacion=20,
        C_fundacion=40,
        H=6,
        t2=0,
        tetha=0,
        betha=90,
        alpha_kb=0,
        t1=0.2,
        h1=0.7,
        b=0.5,
        B=4,
        b1=0.7,
        iterations=10000
    )

    success_probability, uncertainty, sucess_volteo_probability, sucess_delizamiento_probability, sucess_excentricidad_probability = montecarlo.run_simulation()
    print(f"Probabilidad de cumplimiento del sistema: {success_probability:.2%}")
    print(f"Probabilidad de cumplimiento del volteo: {sucess_volteo_probability:.2%}")
    print(f"Probabilidad de cumplimiento del deslizamiento: {sucess_delizamiento_probability:.2%}")
    print(f"Probabilidad de cumplimiento de excentricidad: {sucess_excentricidad_probability:.2%}")
    print(f"Incertidumbre del sistema: {uncertainty:.4f}")

    montecarlo_rankine = Montecarlo_Rankine(Y_rell=18, phi_fundacion=20, C_rell=0, Y_fundacion=19, phi_rell=30, C_fundacion=40, alpha=10, betha=90, H=6, D=1.5, b=0.5, h1=0.7, b1=0.7, b2=2.6, t1=0.2, t2=0, h_rankine=0.46, alpha_rankine=0, y_conc=23.58, phi_conc=0, iterations=100000)
    success_probability, uncertainty, sucess_volteo_probability, sucess_delizamiento_probability, sucess_excentricidad_probability = montecarlo_rankine.run_simulation()
    print(f"Probabilidad de cumplimiento del sistema: {success_probability:.2%}")
    print(f"Probabilidad de cumplimiento del volteo: {sucess_volteo_probability:.2%}")
    print(f"Probabilidad de cumplimiento del deslizamiento: {sucess_delizamiento_probability:.2%}")
    print(f"Probabilidad de cumplimiento de excentricidad: {sucess_excentricidad_probability:.2%}")
    print(f"Incertidumbre del sistema: {uncertainty:.4f}")


if __name__ == "__main__":
    run()