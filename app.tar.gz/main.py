import flet as ft
from calcs.metodo_rankine import Rankine
from calcs.metodo_coloumb import Coloumb
from calcs.simulacion_montecarlo import Montecarlo_Coloumb, Montecarlo_Rankine
from elements.styles import Style
from flet import TextField, ElevatedButton, Column, Text
from calcs.grafica import graficar
from flet.matplotlib_chart import MatplotlibChart

def main(page):
    ct = Style()
    page.title = "Calculo civil"
    page.scroll = ft.ScrollMode.AUTO
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    widthScreen = 1460
    heightPreeliminar = 840
    heightCalcs = 950
    
    def calcular_primero(e):
        B = float(b.value) + float(b1.value) + float(b2.value) + float(t1.value) + float(t2.value)
        container_dibujo.content = MatplotlibChart(graficar(float(b.value), B, float(h1.value), float(b1.value), float(b2.value), float(t1.value), float(t2.value), float(H.value), float(D.value)), expand=True)
        container_dibujo.update()

    alpha = ct.TextField("alpha")
    H = ct.TextField("Altura del muro - H")
    D = ct.TextField("Profundidad del muro - D")
    b = ct.TextField("Corona superior - b")
    h1 = ct.TextField("Peralte de la zapata - h1")
    b1 = ct.TextField("Longitud de la puntera - b1")
    b2 = ct.TextField("Longitud del talon - b2")
    t1 = ct.TextField("Base del triangulo 1 - t1")
    t2 = ct.TextField("Base del triangulo 2 - t2")
    betha = ct.TextField("Calculo del angulo - betha")

    boton_preeliminar = ct.Button(text="Calcular", function=calcular_primero)

    container_preeliminar = ct.Container(
        content=ft.Column([
            ct.Texto(texto="1. Predimensionamiento",titulo=True, color=ft.colors.WHITE),
            alpha,
            H,
            D,
            b,
            h1,
            b1,
            b2,
            t1,
            t2,
            betha,
            boton_preeliminar
        ]),
        width=widthScreen*0.4,
        height=heightPreeliminar,
        padding=50,
        border_radius=20
    )

    container_dibujo=ct.Container(
        content=ct.Texto(texto="Oprima el boton para graficar",titulo=True, color=ft.colors.BLUE),
        width=widthScreen*0.6,
        height=heightPreeliminar,
        border_radius=20,
        color=ft.colors.WHITE
    )

    row_preeliminar = ft.Row([
        container_preeliminar,
        container_dibujo
    ])

    # Muro de relleno
    Y_rell = ct.TextField("Y [KN/M3]")
    phi_rell = ct.TextField("Phi")
    C_rell = ct.TextField("C [Kn/M2]")
    # Muro
    y_muro = ct.TextField("y concreto")
    k_muro = ct.TextField("K 2/3")
    phi_muro = ct.TextField("Inclinacion muro - phi")
    # Fundacion
    Y_fundacion = ct.TextField("Y [KN/M3]")
    phi_fundacion = ct.TextField("Phi")
    C_fundacion = ct.TextField("C [Kn/M2]")

    column_props = ft.Column([
        ct.Texto("Propiedades suelo de relleno", titulo=True),
        Y_rell,
        phi_rell,
        C_rell,
        ct.Texto("Propiedades de muro", titulo=True),
        y_muro,
        k_muro,
        phi_muro,
        ct.Texto("Propiedades suelo fundacion", titulo=True),
        Y_fundacion,
        phi_fundacion,
        C_fundacion
    ])

    container_props = ct.Container(
        content=column_props,
        width=widthScreen*0.5,
        height=heightCalcs,
        padding=50,
        border_radius=20
    )

    def calculo_coloumb():
        coloumb = Coloumb(
            Y_rell=float(Y_rell.value), 
            phi_rell=float(phi_rell.value), 
            C_rell=float(C_rell.value),
            Y_fundacion=float(Y_fundacion.value),
            phi_fundacion=float(phi_fundacion.value),
            y_conc=float(y_muro.value),
            phi_conc=float(phi_muro.value),
            C_fundacion=float(C_fundacion.value),
            alpha=float(alpha.value),
            betha=float(betha.value),
            H=float(H.value),
            d=float(D.value),
            b=float(b.value),
            h1=float(h1.value),
            b1=float(b1.value),
            t1=float(t1.value),
            t2=float(t2.value),
            alpha_kb=float(alpha_method.value),
            k=float(k_muro.value),
            tetha=float(tetha_coloumb.value),
            B = float(b.value) + float(b1.value) + float(b2.value) + float(t1.value) + float(t2.value)
        )

        montecarlo_coloumn = Montecarlo_Coloumb(
            Y_rell=float(Y_rell.value), 
            phi_rell=float(phi_rell.value), 
            C_rell=float(C_rell.value),
            Y_fundacion=float(Y_fundacion.value),
            phi_fundacion=float(phi_fundacion.value),
            y_conc=float(y_muro.value),
            phi_conc=float(phi_muro.value),
            C_fundacion=float(C_fundacion.value),
            alpha=float(alpha.value),
            betha=float(betha.value),
            H=float(H.value),
            d=float(D.value),
            b=float(b.value),
            h1=float(h1.value),
            b1=float(b1.value),
            t1=float(t1.value),
            t2=float(t2.value),
            alpha_kb=float(alpha_method.value),
            k=float(k_muro.value),
            tetha=float(tetha_coloumb.value),
            B = float(b.value) + float(b1.value) + float(b2.value) + float(t1.value) + float(t2.value)
        )

        container_solucion_method.content = ct.Texto(coloumb.ver_resultados() + coloumb.ver_cumplimiento(), titulo=True)
        container_solucion_method.update()

        montecarlo_container.content = ct.Texto(montecarlo_coloumn.run_simulation(), titulo=True)
        montecarlo_container.update()


    def calculo_rankine():
        rankine = Rankine(
            Y_rell=float(Y_rell.value), 
            phi_rell=float(phi_rell.value), 
            C_rell=float(C_rell.value),
            Y_fundacion=float(Y_fundacion.value),
            phi_fundacion=float(phi_fundacion.value),
            y_conc=float(y_muro.value),
            phi_conc=float(phi_muro.value),
            C_fundacion=float(C_fundacion.value),
            alpha=float(alpha.value),
            betha=float(betha.value),
            H=float(H.value),
            D=float(D.value),
            b=float(b.value),
            h1=float(h1.value),
            b1=float(b1.value),
            b2=float(b2.value),
            t1=float(t1.value),
            t2=float(t2.value),
            alpha_rankine=float(alpha_method.value),
            h_rankine=float(h_rankine.value)
            )

        montecarlo_rankine = Montecarlo_Rankine(
            Y_rell=float(Y_rell.value), 
            phi_rell=float(phi_rell.value), 
            C_rell=float(C_rell.value),
            Y_fundacion=float(Y_fundacion.value),
            phi_fundacion=float(phi_fundacion.value),
            y_conc=float(y_muro.value),
            phi_conc=float(phi_muro.value),
            C_fundacion=float(C_fundacion.value),
            alpha=float(alpha.value),
            betha=float(betha.value),
            H=float(H.value),
            D=float(D.value),
            b=float(b.value),
            h1=float(h1.value),
            b1=float(b1.value),
            b2=float(b2.value),
            t1=float(t1.value),
            t2=float(t2.value),
            alpha_rankine=float(alpha_method.value),
            h_rankine=float(h_rankine.value)
        )
        
        container_solucion_method.content = ct.Texto(rankine.ver_resultados() + rankine.ver_cumplimiento(), titulo=True)
        container_solucion_method.update()

        montecarlo_container.content = ct.Texto(montecarlo_rankine.run_simulation(), titulo=True)
        montecarlo_container.update()

    def calcular_solucion(e):
        if opciones.value == "Rankine":
            calculo_rankine()
        else:
            calculo_coloumb()


    def opcion_seleccionada(e):
        if e.control.value == "Coloumb":
            column_method_seleccionado.controls = [
            tittle_method,
            opciones,
            alpha_method,
            tetha_coloumb,
            btn_Calcular
        ]
        else:
            column_method_seleccionado.controls = [
            tittle_method,
            opciones,
            alpha_method,
            h_rankine,
            btn_Calcular
        ]
        column_method_seleccionado.update()

    h_rankine = ct.TextField("h metodo:")
    tetha_coloumb = ct.TextField("tetha metodo:")
    alpha_method = ct.TextField("Alpha metodo:")
    btn_Calcular = ct.Button("Calcular", function=calcular_solucion)
    tittle_method = ct.Texto("Seleccione el metodo", titulo=True)
    opciones = ft.Dropdown(
            options = [
                ft.dropdown.Option("Coloumb"),
                ft.dropdown.Option("Rankine"),
            ],
            on_change = opcion_seleccionada
        )

    column_method_seleccionado = ft.Column([
        tittle_method,
        opciones,
        ct.Texto("Seleccione el metodo a usar")
    ])

    container_select_method = ct.Container(
        content=column_method_seleccionado,
        width=widthScreen*0.5,
        height=heightCalcs*0.38,
        border_radius=20,
        padding=50
    )

    container_solucion_method = ct.Container(
        content= ct.Texto("Espacio de Solucion", titulo=True),
        width=widthScreen*0.5,
        height=heightCalcs*0.6,
        border_radius=20,
        padding=50
    )

    column_method = ft.Column([
        container_select_method,
        container_solucion_method
    ])

    row_props = ft.Row([
        container_props,
        column_method
    ])

    column_mother= ft.Column([row_preeliminar, row_props])
    montecarlo_container = ct.Container(
        content= ct.Texto("Espacio de Solucion probabilistica", titulo=True),
        width=widthScreen,
        height=heightCalcs*0.4,
        border_radius=20,
        padding=50
    )

    page.add(column_mother, montecarlo_container)

ft.app(target=main)
