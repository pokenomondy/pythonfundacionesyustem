import flet as ft

class Style:
    def Texto(self, texto, titulo=False, color = 0):
        return ft.Text(
            texto,
            size=20 if titulo else 15,
            color=ft.colors.WHITE if color == 0 else color
            )

    def Container(self, content, margin = 0, padding=0, alignment = 0, width=0, height=0, border_radius=0, color=0):
        return ft.Container(
            content=content,
            margin= 0 if margin == 0 else margin,
            padding= 10 if padding == 0 else padding,
            alignment=ft.alignment.center if alignment == 0 else alignment,
            width= -1 if width == 0 else width,
            height= -1 if height == 0 else height,
            border_radius= 0 if border_radius == 0 else border_radius,
            bgcolor=ft.colors.BLUE if color == 0 else color
        )

    def Button(self, text, function, data=0, icon=""):
        return ft.ElevatedButton(
            text=text,
            on_click=function,
            data=data,
            icon=icon
        )

    def TextField(self, label, icon=""):
        return ft.TextField(
            label=label,
            icon=icon,
            color=ft.colors.WHITE,
            keyboard_type=ft.KeyboardType.NUMBER
        )